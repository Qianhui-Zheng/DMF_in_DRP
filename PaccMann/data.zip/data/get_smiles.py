import pandas as pd
import numpy as np
import requests
from itertools import product
from rdkit import Chem
from rdkit.Chem import AllChem

def getcid(drugname):
    cids = []
    for i in range(0, len(drugname)):
        url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/name/{drugname[i]}/cids/JSON"
        try:
            r = requests.get(url)
            r.raise_for_status()
            response = r.json()
            if "IdentifierList" in response:
                cids.append(response["IdentifierList"]["CID"][0])
            else:
                raise ValueError(f"Could not find matches for compound: {drugname[i]}")
        except requests.exceptions.HTTPError as errh:
            cids.append("none")
    return cids
def getdruginfo(drugname):
    cid = getcid(drugname)
    druginfo = pd.DataFrame([cid,drugname])
    druginfo = druginfo.transpose()
    druginfo.columns = ["cid", "drug_name"]
    return druginfo

gdsc_druginfo = getdruginfo(gdsc_drugname)
pr_druginfo = getdruginfo(pr_drugname)

def smiles_from_pubchem_cids(cids):

    url = f"https://pubchem.ncbi.nlm.nih.gov/rest/pug/compound/cid/{','.join(map(str, cids))}/property/CanonicalSMILES/JSON"
    r = requests.get(url)
    r.raise_for_status()
    return [item["CanonicalSMILES"] for item in r.json()["PropertyTable"]["Properties"]]


pr_druginfo1 = pr_druginfo
pr_druginfo1['smiles'] = smiles_from_pubchem_cids(pr_druginfo1['cid'])